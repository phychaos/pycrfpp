#!/usr/bin/ruby

import CRFPP
import sys

try:
    print('\n测试python3 CRFPP...\n')
    # -v 3: access deep information like alpha,beta,prob
    # -nN: enable nbest output. N should be >= 2
    tagger = CRFPP.Tagger("-m ./model -v 3 -n2")
    
    # clear internal context
    tagger.clear()
    
    # add context
    context = '只有站在百姓的出发点，达到“你就是我、我就是你”，才可能把工作真正做到位。'
    for word in context:
        tagger.add(word)
    
    tagger.parse()
    
    size = tagger.size()
    for i in range(0, size):
        w, tag = tagger.x(i, 0), tagger.y2(i)
        print(w + '\t' + tag, end='\n')
    print('\n已成功安装python3 CRFPP！')


except RuntimeError as e:
    print("RuntimeError: ", e, end=' ')
